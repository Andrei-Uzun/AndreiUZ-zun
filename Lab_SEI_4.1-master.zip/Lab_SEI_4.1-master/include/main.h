#ifndef main_h
#define main_h

#include <Arduino.h>
#include "own_stdio.h"
#include "freeRTOS_task_scheduler.h"

void setup  (void); 
void loop   (void);

#endif // !main_h