#include "main.h"

void setup() {
  tasksSetup();
}

void loop() {

}
